from test import get_menu

get_menu()